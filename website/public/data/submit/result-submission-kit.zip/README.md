# PolyCodeEval Result Submission Kit

Submit locally evaluated results through a GitHub pull request.

1. Generate code and run the official PolyCodeEval evaluator locally.
2. Keep the evaluator output unchanged below `evaluation/`.
3. Complete `submission.json` or use `scripts/submission/prepare_submission.py`.
4. Add optional public logs below `logs/`.
5. Validate the package on the website or with `validate_submission.py`.

Package layout:

```text
submission.json
evaluation/
  summary.json
  <language>/<project>/<task>.json
logs/  # optional
```

Generated code is not part of a community result submission. Partial result sets
are accepted; missing benchmark tasks receive zero in fixed-denominator ranking.
